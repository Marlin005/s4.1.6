export const TRANSLATION_RU = `
<?xml version="1.0" encoding="UTF-8" ?>
<xliff version="1.2" xmlns="urn:oasis:names:tc:xliff:document:1.2">
    <file source-language="ru" datatype="plaintext" original="ng2.template">
        <body>
            <trans-unit id="4e7f5f07ae8e67878f35b34bcee10e39300ff41a" datatype="html">
                <source>Orders</source>
                <target>Заказы</target>
            </trans-unit>
            <trans-unit id="61e0f26d843eec0b33ff475e111b0c2f7a80b835" datatype="html">
                <source>Statistics</source>
                <target>Статистика</target>
            </trans-unit>
            <trans-unit id="532152365f64d8738343423767f1130c1a451e78" datatype="html">
                <source>Catalog</source>
                <target>Каталог</target>
            </trans-unit>
            <trans-unit id="121cc5391cd2a5115bc2b3160379ee5b36cd7716" datatype="html">
                <source>Settings</source>
                <target>Настройки</target>
            </trans-unit>
            <trans-unit id="1f332ec66f3bc8d943c248091be7f92772ba280f" datatype="html">
                <source>Expand</source>
                <target>Развернуть</target>
            </trans-unit>
            <trans-unit id="e8bcb762b48cf52fbea66ce9c4f6b970b99a80fd" datatype="html">
                <source>Collapse</source>
                <target>Свернуть</target>
            </trans-unit>
            <trans-unit id="locale" datatype="html">
                <source>Locale</source>
                <target>Локаль</target>
            </trans-unit>
            <trans-unit id="c64747f0bc3848d47c89e0af17d0c199b44ad0de" datatype="html">
                <source>Parameter</source>
                <target>Параметр</target>
            </trans-unit>
            <trans-unit id="5049e204c14c648691ac775a64fb504467aeb549" datatype="html">
                <source>Value</source>
                <target>Значение</target>
            </trans-unit>
        </body>
    </file>
</xliff>
`;
