import {Component, OnInit} from '@angular/core';

@Component({
    selector: 'app-catalog',
    templateUrl: './templates/catalog.component.html'
})
export class CatalogComponent implements OnInit {

    static title = 'CATALOG';

    constructor() {
    }

    ngOnInit() {
    }

}
