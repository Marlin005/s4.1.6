export class FieldTypeProperty {
    constructor(
        public name: string,
        public title: string,
        public default_value: string
    ) { }
}
