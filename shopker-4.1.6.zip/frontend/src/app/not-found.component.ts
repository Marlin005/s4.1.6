import {Component} from '@angular/core';

@Component({
    selector: 'app-not-found',
    template: `<h3 class="mt-3">Page not found.</h3>`
})
export class NotFoundComponent {

}
