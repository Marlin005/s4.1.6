export interface EntityTranslation {
    lang: string;
    value: string;
    fieldName?: string;
}
