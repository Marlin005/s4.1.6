export class MultiValues {
    constructor(
        public values: (string | number)[],
        public checked: boolean[]
    ) { }
}
