export interface DataList<T> {
    items: T[];
    total: number;
}
