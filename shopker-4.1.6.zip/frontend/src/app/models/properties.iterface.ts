export interface Properties {
    [key: string]: string|number|string[];
}
