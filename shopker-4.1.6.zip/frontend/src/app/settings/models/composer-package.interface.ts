export interface ComposerPackage {
    name: string;
    type: string;
    version: string;
    prettyVersion?: string;
}
