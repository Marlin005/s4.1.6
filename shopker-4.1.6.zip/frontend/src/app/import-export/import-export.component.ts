import {Component, OnInit} from '@angular/core';

@Component({
    selector: 'app-import-export',
    templateUrl: './import-export.template.html'
})
export class ImportExportComponent implements OnInit {

    static title = 'IMPORT_EXPORT';

    constructor() {
    }

    ngOnInit() {
    }

}
