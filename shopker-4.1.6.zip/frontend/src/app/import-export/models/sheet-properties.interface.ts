import {FieldOption} from './import-configuration.model';

export interface SheetProperties {
    fieldsOptions: FieldOption[];
    rowsQuantity: number;
}
