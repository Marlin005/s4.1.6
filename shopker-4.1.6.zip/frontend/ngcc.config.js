module.exports = {
    packages: {
        'ng2-dragula': {
            entryPoints: { './dist': { ignore: true, } },
        },
    }
};