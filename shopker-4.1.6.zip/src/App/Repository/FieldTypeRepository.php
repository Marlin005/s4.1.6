<?php

namespace App\Repository;

/**
 * FieldTypeRepository
 */
class FieldTypeRepository extends BaseRepository
{



}