<?php

namespace App\Repository;

/**
 * ContentTypeRepository
 */
class ContentTypeRepository extends BaseRepository
{



}